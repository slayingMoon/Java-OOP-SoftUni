package WorkingWithAbstraction_Exercise.TrafficLights;

public enum TrafficLights {
    RED,
    GREEN,
    YELLOW;
}
