package InterfacesAndAbstraction_Exercise.Telephony;

public interface Browsable {
    String browse();
}
