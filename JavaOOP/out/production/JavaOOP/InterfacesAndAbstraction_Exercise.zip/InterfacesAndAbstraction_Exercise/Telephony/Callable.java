package InterfacesAndAbstraction_Exercise.Telephony;

public interface Callable {
    String call();
}
