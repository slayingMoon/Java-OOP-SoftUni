package Polymorphism_Exercise.WildFarm.foods;

public class Vegetable extends Food{
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
