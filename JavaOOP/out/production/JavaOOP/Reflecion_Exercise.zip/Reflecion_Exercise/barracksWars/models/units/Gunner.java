package Reflecion_Exercise.barracksWars.models.units;

public class Gunner extends AbstractUnit {
    private static final int GUNNER_HEALTH = 20;
    private static final int GUNNER_DAMAGE = 20;

    public Gunner(int GUNNER_HEALTH, int GUNNER_DAMAGE) {
        super(GUNNER_HEALTH, GUNNER_DAMAGE);
    }
}
