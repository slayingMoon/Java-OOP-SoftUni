package Reflecion_Exercise.barracksWars.interfaces;

public interface Runnable {
	void run();
}
