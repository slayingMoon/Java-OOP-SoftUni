package Reflecion_Exercise.barracksWars.interfaces;

public interface Executable {

	String execute();

}
