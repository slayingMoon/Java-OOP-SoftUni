package Reflecion_Exercise.barracksWars.interfaces;

public interface Unit extends Destroyable, Attacker {
}
