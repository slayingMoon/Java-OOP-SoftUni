package Reflecion_Exercise.barracksWars.interfaces;

public interface Attacker {
    
    int getAttackDamage();
}
